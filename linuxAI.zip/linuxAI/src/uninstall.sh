#!/usr/bin/env bash

sudo rm -rf /opt/linuxAI
sudo rm -rf /opt/linuxAI/google-cloud-sdk
sudo rm -f /usr/bin/gcloud
sudo rm -rf /tmp/portaudio
sudo rm -rf /tmp/PyAudio-0.2.11
rm -rf /home/$USER/.linuxAI