
Composition of tags
-------------------

.. autoclass:: pyasn1.type.tag.TagSet
   :members:
