
Distinguished Encoding Rules
----------------------------

.. autofunction:: pyasn1.codec.der.encoder.encode(value)

.. autofunction:: pyasn1.codec.der.decoder.decode(substrate, asn1Spec=None)
