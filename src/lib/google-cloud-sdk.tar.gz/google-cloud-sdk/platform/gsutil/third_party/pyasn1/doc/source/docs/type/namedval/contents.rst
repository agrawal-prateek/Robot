
Enumerating numbers
-------------------

Some ASN.1 types such as :py:class:`~pyasn1.type.univ.Integer`,
:py:class:`~pyasn1.type.univ.Enumerated` and
:py:class:`~pyasn1.type.univ.BitString` may enumerate their values
with human-friendly labels.

.. toctree::
   :maxdepth: 2

   /docs/type/namedval/namedval
